package TEST1;

public class Table15 {
	public static void main(String[] args) {
		int n=15;
		for(int i=1;i<=10;i++) {
			int mul=n*i;
			System.out.println(n+"*"+i+"="+mul);
		}
	}
}
