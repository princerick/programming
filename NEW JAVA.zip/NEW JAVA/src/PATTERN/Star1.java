package PATTERN;

public class Star1 {
	
//							  	    print *
		
	
//	public static void main(String[] args) {
//		System.out.println("*");
//	}
	
	
//									print * * * * *
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			System.out.print("* ");
//		}
//	}
	
	
//									print  4 4 4 4 4
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			System.out.print("4 ");
//		}
//	}
	
	
//									print 1 0 1 0 1 0	
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=6;i++) {
//			if(i%2==0) {
//				System.out.print("0 ");
//			}
//			else {
//				System.out.print("1 ");
//			}
//		}
//	}
	
	
//							print	 * * * * *
//								  	 * * * * *
//								  	 * * * * *
//								  	 * * * * *
//								  	 * * * * *
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			for(int j=1;j<=5;j++) {
//				System.out.print("* ");
//			}
//			System.out.println();
//		}
//	}
	
	
//							print	 1 2 3 4 5
// 									 1 2 3 4 5
// 	 								 1 2 3 4 5
// 									 1 2 3 4 5
// 									 1 2 3 4 5
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			for(int j=1;j<=5;j++) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
//	}
	
	
//							print	 1 1 1 1 1
//	 								 2 2 2 2 2
//		 							 3 3 3 3 3
//									 4 4 4 4 4
//									 5 5 5 5 5
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			for(int j=1;j<=5;j++) {
//				System.out.print(i+" ");
//			}
//			System.out.println();
//		}
//	}
	
	
//							print	 1 0 1 0 1
//	 								 1 0 1 0 1
//	 								 1 0 1 0 1
//	 								 1 0 1 0 1
//									 1 0 1 0 1
	
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			for(int j=1;j<=5;j++) {
//				if(j%2==0) {
//				System.out.print("0 ");
//				}
//				else {
//					System.out.print("1 ");
//				}
//			}
//			System.out.println();
//		}
//	}
	
	
//							print	 1 2 3 4 5
//									 6 7 8 9 10
//									 11 12 13 14 15
//									 16 17 18 19 20
//									 21 22 23 24 25
	
	
	public static void main(String[] args) {
		int count=1;
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=5;j++) {
				System.out.print(count+++" ");
			}
			System.out.println();
		}
	}
}
