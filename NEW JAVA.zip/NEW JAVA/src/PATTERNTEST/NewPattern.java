package PATTERNTEST;

import java.util.Scanner;

public class NewPattern {

	
//										   1
	
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++) {
//			for(int j=1;j<=5;j++) {
//				if(i==1 || i==5 || j==1 || j==5) {
//					System.out.print("* ");
//				}
//				else {
//					System.out.print("  ");
//				}
//			}
//			System.out.println();
//		}
//	}
	
	
//											2
	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enetr the number of rows");
//		int r=sc.nextInt();
//		System.out.println("Enetr the number of columns");
//		int c=sc.nextInt();
//		char ch='a';
//		for(int i=1;i<=r;i++) {
//			for(int j=1;j<=c;j++) {
//				if(i==1 || i==r || j==1 || j==c) {
//					System.out.print(ch+++" ");
//				}
//				else {
//					System.out.print("  ");
//				}
//			}
//			System.out.println();
//		}
//	}
	
	
// 											3
	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enetr the number of rows");
//		int r=sc.nextInt();
//		System.out.println("Enetr the number of columns");
//		int c=sc.nextInt();
//		for(int i=1;i<=r;i++) {
//			for(int j=1;j<=c;j++) {
//				if(i==1 || i==r || j==1 || j==c || i+j==r+1 || i==j) {
//					System.out.print(i+" ");
//				}
//				else {
//					System.out.print("  ");
//				}
//			}
//			System.out.println();
//		}
//	}
//	
	
//											4
	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enetr the number of rows");
//		int r=sc.nextInt();
//		System.out.println("Enetr the number of columns");
//		int c=sc.nextInt();
//		for(int i=1;i<=r;i++) {
//			for(int j=1;j<=c;j++) {
//				if((i==2 && j==3) || (i==3 && j==2) || (i==3 && j==4) || (i==4 && j==3)) {
//					System.out.print("  ");
//				}
//				else {
//					System.out.print("* ");
//				}
//			}
//			System.out.println();
//		}
//	}
	
	
//											5
	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enetr the number of rows");
//		int r=sc.nextInt();
//		System.out.println("Enetr the number of columns");
//		int c=sc.nextInt();
//		for(int i=r;i>=1;i--) {
//			for(int j=c;j>=i;j--) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
//	}
	
	
//											6
	
//	public static void main(String[] args) {
//		int a=5;
//		for(int i=5;i>=1;i--) {
//			for(int j=5;j>=i;j--) {
//				System.out.print(a+" ");
//			}
//			a--;
//			System.out.println();
//		}
//	}
}
