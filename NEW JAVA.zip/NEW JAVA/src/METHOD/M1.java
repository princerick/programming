package METHOD;

public class M1 {
	static void add()
	{
		int a=10;
		int b=20;
		int sum=a+b;
		System.out.println(sum);
	}
	public static void main(String[] args) {
		add();
	}
}
