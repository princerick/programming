package JAVA1;
public class Ascii {
	public static void main(String[] args) {
		char ch='a';
		do {
			System.out.println((int)ch);
			ch++;
		}while(ch<='z');
	}
}
