package JAVA1;

//import java.util.Scanner;

public class RectanglePerimeter {
	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the length of a rectangle:");
//		double l=sc.nextDouble();
//		System.out.println("Enter the width of a rectangle:");
//		double b=sc.nextDouble();
//		double perimeter=2*(l+b);
//		System.out.println("perimeter of a rectangle is "+perimeter);
//		int x=9,y=12,a=2,b=4,c=6;
//		int exp=(3+4*x)/5-10*(y-5)*(a+b+c)/x+9*(4/x+(9+x)/y);
//		System.out.println(exp);
		double x=10.5;
		x/=4+2.5*2.5;
		System.err.println(x);
	}
}
