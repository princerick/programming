package JAVA1;
public class Greatest {
	public static void main(String[] args) {
		int a=50, b=70;
		int result= a>b ? a :b;
		System.out.println(result+" is greater");
	}
}	