package JAVA1;
public class Cast1 {
	public static void main(String[] args) {
//		double d=10.325;
//		int a=(int)d;
//		System.out.println(a);
//		
//		int a1=68;
//		char ch=(char)a1;
//		System.out.println(ch);
//		
//		char z='Z';
//		int a3=z;
//		System.out.println(a3);
//		
//		int money=500;
//		double price=13.5;
//		int choco=(int)(money/price);
//		//int choco1=(int)choco;
//		System.out.println("he can buy "+choco+" chocolates");
//		byte n=50;
//		short a=n;
//		int b=n;
//		long c=n;
//		float d=n;
//		double e=n;
//		char ch=(char)n;
//		System.out.println(n);
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(e);
//		System.out.println(ch);
//		short n=35;
//		int b=n;
//		long c=n;
//		float d=n;
//		double e=n;
//		char ch=(char)n;
//		System.out.println(n);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(e);
//		System.out.println(ch);
//		double n=36.9d;
//		byte a=(byte)n;
//		short b1=(short)n;
//		int b=(int)n;
//		long c=(long)n;
//		float d=(float)n;
//		char ch=(char)n;
//		System.out.println(n);
//		System.out.println(a);
//		System.out.println(b1);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(ch);
		int money=500;
		double price=77.65;
		double apple=money/price;
		System.out.println("he can buy "+apple+" kg apples");
		
		int money1=250;
		double price1=13.5;
		int choco=(int)(money1/price1);
		System.out.println("he can buy "+choco+" chocolates");
		
	}
}
